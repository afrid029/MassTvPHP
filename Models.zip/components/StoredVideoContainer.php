<html>

<head>
    <link rel="stylesheet" href="../masstv/Assets/CSS/storedVideoContainer.css">
</head>

<body>

    <div class="wrapper">
        <div class="otherVideo">
            <h4>Our Playlist</h4>
            <hr />
        </div>
        <?php include('./components/storedVideo.php') ?>
        <?php include('./components/storedVideo.php') ?>
        <?php include('./components/storedVideo.php') ?>
        <?php include('./components/storedVideo.php') ?>

        <?php include('./components/footer.php') ?>
    </div>
    
</body>

</html>