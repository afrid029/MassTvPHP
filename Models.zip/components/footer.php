<html>

<head>
<link rel="stylesheet" href="../masstv/Assets/CSS/footer.css">
</head>

<body>

    <div class='footer'>
        <h3>Contact</h3>
        <p class="p home">
            <img class="footerIcon" src="../masstv/Assets/images/home.svg" />Mass Production Limited
            <img style="width: 24px;" src="../masstv/Assets/images/forward.svg" />
        </p>
        <p class="p">
        <img class="footerIcon" src="../masstv/Assets/images/location.svg" />215 Mississauga Valley Blvd, Mississauga, ON, L5A1Y7
        </p>
        <p class="p">
        <img class="footerIcon" src="../masstv/Assets/images/call.svg" />+1-905-393-4080
        </p>
        <p class="p">
        <img class="footerIcon" src="../masstv/Assets/images/time.svg" />Mon - Fri  &nbsp; 09:00Am - 06:00Pm
        </p>
        <p class="p">
        <img class="footerIcon" src="../masstv/Assets/images/letter.svg" /> info@masspro.ca
        </p>

    </div>

</body>

</html>