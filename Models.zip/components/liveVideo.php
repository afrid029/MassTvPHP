<html>

<head>
    <link rel="stylesheet" href="../masstv/Assets/CSS/liveVideo.css">
</head>

<body>
    <div class="hlsWrapper">
        <div class="hls-player">
            <video  controls autoPlay={true} muted={true} playsInline={true} width="100%" />

        </div>
    </div>
</body>

</html>