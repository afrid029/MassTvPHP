<html>

<head>
    <link rel="stylesheet" href="../masstv/Assets/CSS/storedVideo.css">
</head>

<body>
    <div class="card-container">
    <div class="card">
        <div class="card-media">

            <div class="playIcon">
                <img src="../masstv/Assets/images/play-button.svg" alt="">
            </div>
        </div>
        <div class="card-content">
            <p>Hello every ss sdfsf sdfsdf sfsdfsd sdfsdf sdfdsf </p>
        </div>
    </div>
    <div class="btn-del">Delete</div>
    </div>
</body>

</html>