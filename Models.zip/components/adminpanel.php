<html>
    <head>
    
    <link rel="stylesheet" href="../masstv/Assets/CSS/adminPanel.css">
    </head>
    <body>
        
    <div class="adminPanel">
                <div class='panel'>
                    Change Live Stream
                </div>
                <div class='panel'>
                    Add Video
                </div>
                <div class='panel'>
                    Update Logo
                </div>
            </div>
    </body>
</html>