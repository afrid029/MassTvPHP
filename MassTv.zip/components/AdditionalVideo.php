<?php 
$data = json_decode(file_get_contents('php://input'), true);

// $title = $data['title'];
// $url = $data['url'];
// $image = $data['image'];
// $id = $data['ID'];

// include('./storedVideo.php');
?>
