

<html>
    <head>
    <title>MASS TV</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/jpg" href="Assets/images/mainLogo.jpg" />
        <link rel="stylesheet" href="/Assets/CSS/error.css">
    </head>

    <script> 
        function navigateToHome(){
            window.open("/","_self");
        }
    </script>

    <body>
    <div class="error">
            <h1 ><span style="margin-right:10px;"> <img style="margin-right:10px; width: 24px; height: 24px" src="/Assets/images/file-corrupted-svgrepo-com.svg" alt="Icon" /></span>Page Not Found</h1>
           
            <div class="goback" onclick="navigateToHome()">
                   
            Go to Home</div>
        </div>
        <div class="foot">

        </div>
    </body>
</html>