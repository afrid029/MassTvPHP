<html>

<head>

  

</head>

<body>

    <div class="modal-overlay" id="VideoNotAvailableModel">
        <div class="modal-content">
            <div class="heading">
                <h2 style="margin-bottom:4px; margin: auto;">
                    Video Player
                </h2>
                <div class="close-button" onclick="handlePlayer({value: 'false'})">
                    Close
                </div>
            </div>


            <div
                style='
                display: flex;
                align-items: center;
                height: inherit;
                justify-content: center;'>
                <h4>Video Not Supported</h4>
            </div>


        </div>
    </div>

</body>

</html>