function openSocialLink(url) {
  //alert('Opening ' + url);
  window.open(url, "_blank");
}


